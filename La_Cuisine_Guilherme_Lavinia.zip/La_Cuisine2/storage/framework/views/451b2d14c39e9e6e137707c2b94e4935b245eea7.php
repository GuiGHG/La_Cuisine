<?php $__env->startSection('content'); ?>
<h1>Tela de Cadastro</h1>
<form action="/create/user">
        <input type="text" name="nome" placeholder="Digite o usuario">
        <input type="text" name="senha" placeholder="Digite a senha">
        <input type="text" name="email" placeholder="Digite o email">
        <input type="submit" name="submit" value="Enviar">
    </form>
                
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifsp/Documents/Projeto_Filme/La_Cuisine/resources/views/lacuisine.blade.php ENDPATH**/ ?>