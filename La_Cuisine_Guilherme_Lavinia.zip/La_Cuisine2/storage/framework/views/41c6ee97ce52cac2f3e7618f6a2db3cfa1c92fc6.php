<?php $__env->startSection('content_user'); ?>
<style>
    input[type=text] {
        width: 50%;
        color: gray;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    input[type=submit] {
        width: 30%;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    div {
        border-radius: 5px;
        background-color: #f2f2f2;
        padding: 20px;
    }

</style>
<h1>Cria Post</h1>
<form action="/create/post">
        <input type="text" name="texto" placeholder="Digite o texto">
        <input type="text" name="comentario" placeholder="Digite o comentario">
        <input type="text" name="email" placeholder="Digite o email">
        <br>
        <input type="submit" name="submit" value="Enviar">
        <?php $__currentLoopData = $createpost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <br>
                          *POST* ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                          <br>
                          <?php echo e($post->texto); ?> 
                          <br>
                          <br>
                          <br>
                          Comentarios do Post Acima:
                          <br>
                          <?php echo e($post->comentario); ?>

                          <a href="<?php echo e(route('delete.post', ['id' => $post->id])); ?>">Apagar</a>
                          <br>
                          <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifsp/Documents/Projeto_Filme/La_Cuisine2/resources/views/createpost.blade.php ENDPATH**/ ?>