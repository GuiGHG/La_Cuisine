<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class La_Cuisine_Teste extends Model
{
    //
}
