<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LaCuisine extends Model
{
    //
    protected $table = 'la_cuisines';
}
