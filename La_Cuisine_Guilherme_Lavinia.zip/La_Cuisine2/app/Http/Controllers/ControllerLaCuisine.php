<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\LaCuisine;
use App\Posts;

class ControllerLaCuisine extends Controller
{
    public function create(Request $request){

//    	$messages = ['nome.required'=>'Maximo de 500 caracteres para o nome','email.required'=>'É necessário um e-mail valido','senha.required'=>'É necessario que a senha possua no minimo 6 caracteres, letras,numeros e simbolos especiais'];
 //   	$this.validate($request, [
 //   		'nome' => 'required|max:255',
 //   		'senha' => 'required|min:6',
 //   		'email' => 'required|email',
 //   	],$messages);

		$cuisine = new LaCuisine;
		$cuisine->nome = $request->nome;
		$cuisine->senha = $request->senha;
		$cuisine->email = $request->email;
		if (strlen($cuisine->senha) < 6){
			return 'Senha com menos de 6 carcateres';
 		 }
 		 if (!(preg_match('/[0-9]/', $cuisine->senha))){ 
 		 	return 'Senha sem numero';	
 		 }
		
		$cuisine->save();
		//return redirect()->back();
		return view('index')->with('index', $cuisine);
	}

	public function index(){
		$cuisine = LaCuisine::all();
		return view('lacuisine')->with('lacuisine', $cuisine);
	}

	public function index2(){
		$posts = Posts::all();
		return view('createpost')->with('createpost', $posts);
	}

	public function home(Request $request){
		$cuisine = LaCuisine::all();
		$posts = Posts::all();

		$cuisine = new LaCuisine;
		$cuisine->nome = $request->nome;
		$cuisine->senha = $request->senha;
		$user = LaCuisine::where('nome','=', $cuisine->nome)->first();
		$pass = LaCuisine::where('senha','=', $cuisine->senha)->first();
		$status = LaCuisine::where('status','=', $cuisine->status)->first();
		if ($user <> null){
			if ($pass <> null){
				if ($status == 'A'){
					return view('createpost')->with('createpost', $posts);
				}
				else {
				return view('home')->with('home', $posts);
				}
			}
		}

		return redirect()->back();
	}

	public function createpost(Request $request){
 
		$post = new Posts;
		$post->texto = $request->texto;
		$post->comentario = $request->comentario;
		$post->email = $request->email;
		
		
		$post->save();
		//return redirect()->back();
		return view('createpost')->with('createpost', $post);
	}

	public function delete($id){
    	$posts = Posts::find($id);
    	$posts->delete();
    	return redirect()->back();
	}
}
