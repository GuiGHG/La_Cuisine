<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLaCuisineTestesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('la__cuisine__testes', function (Blueprint $table) {
            $table->increments('id');
            $table->string('nome',255);
            $table->string('email');
            $table->string('senha',16);
            $table->string('status',1)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('la__cuisine__testes');
    }
}
